

module.exports = {
  mongo_url:"mongodb://nnavedijaz480:tayyab5588@ac-ge6iaez-shard-00-00.oldzi2q.mongodb.net:27017,ac-ge6iaez-shard-00-01.oldzi2q.mongodb.net:27017,ac-ge6iaez-shard-00-02.oldzi2q.mongodb.net:27017/?ssl=true&replicaSet=atlas-gw4dx5-shard-0&authSource=admin&retryWrites=true&w=majority"

}