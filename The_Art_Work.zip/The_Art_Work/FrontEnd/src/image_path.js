const Image_path ="https://apis.theartworks.io/images/";
//  const Image_path ="https://mirrors-innovations.com/new_apis/images/";

export default Image_path;