// const Connection ="http://192.168.100.9:8080/api/user/";
const Connection ="https://apis.theartworks.io/new_apis/";
// const Connection ="https://mirrors-innovations.com/new_apis/";

export default Connection;